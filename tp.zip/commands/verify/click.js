
const { MessageEmbed } = require('discord.js')
const Discord = require('discord.js')
const Captcha = require("@haileybot/captcha-generator");
module.exports = {
  name: "v.click",
  aliases: ["v.click"],

  run: (client, message, args) => {


// Use this function for blocking certain commands or features from automated self-bots

	let captcha = new Captcha();
message.channel.send(
		"**Enter the text shown in the image below:**",
		new Discord.MessageAttachment(captcha.JPEGStream, "captcha.jpeg")
	);
	let collector = message.channel.createMessageCollector(m => m.author.id === message.author.id);
	collector.on("collect", m => {
	 if (m.content.toUpperCase() === captcha.value) message.channel.send("Verified Successfully!");
		else message.channel.send("Failed Verification!");
		collector.stop();
	});
}};
