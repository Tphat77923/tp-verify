const Discord = require("discord.js"), moment = require("moment");

  const db = require("quick.db")
//npm i discord.js moment
module.exports = {
  name: "tv.sbot",
  aliases: ["v.botadd"],

  run: (client, message, args) => {
    try{
    message.channel.send('🤖📥');
    const User = message.mentions.members.first() || message.guild.members.cache.get(args[0])
    db.set(`sb_${message.guild.id}`,User.id);
    message.channel.send('🤖✅');
    }catch(e){
console.error(e)
      message.channel.send(`an error was occurred ${e}`)
}

  }
}
    