const Discord = require("discord.js")
const db = require("quick.db")

module.exports = {
  name: "v.setlog",
  aliases: ["v.log"],
  category: ":frame_photo: WELCOME",

  run: (client, message, args) => {
   if (!message.member.hasPermission("ADMINISTRATION")) {
      return message.channel.send("You do not enough permission to use this command.");
    }
 let channel = message.mentions.channels.first()

    if (!channel) {
      return message.channel.send("You have to specify the channel")
    }
  db.set(`log_${message.guild.id}`, channel.id)


// This code is made by Supreme#2401
    
    message.channel.send(`log has been set as ${channel}.`)
  }
}