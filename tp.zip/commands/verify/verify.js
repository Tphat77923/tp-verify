const Discord = require("discord.js")
const db = require("quick.db")
const { MessageEmbed } = require('discord.js')
const Captcha = require("@haileybot/captcha-generator");
module.exports = {
  name: "v.verify",
  aliases: ["v.verication"],
  category: ":frame_photo: WELCOME",
  usage: "st <link>",
  description: "Set the img for welcome channel",
  run: (client, message, args) => {
    let captcha = new Captcha();
message.channel.send(
		"**Enter the text shown in the image below:**",
		new Discord.MessageAttachment(captcha.JPEGStream, "captcha.jpeg")
	);
	let collector = message.channel.createMessageCollector(m => m.author.id === message.author.id);
    
	collector.on("collect", m => {
    if (m.content.toUpperCase() === captcha.value) {
    message.channel.send("please wait...");
      message.channel.send("if you a new member,type v.verify to start verify!")
                                                     let rRole = db.get(`verole_${message.guild.id}`)
    let rerole = db.get(`srrole_${message.guild.id}`)
    let log = db.get(`log_${message.guild.id}`)
    
    const chx = db.get(`verify_${message.guild.id}`);
const chan = client.channels.cache.get(chx);
if (message.channel.name == chan.name) {
const logch = client.channels.cache.get(log);
    let myRole = message.guild.roles.cache.get(rRole);
    let reerole = message.guild.roles.cache.get(rerole);

let user = message.member;


user.roles.add(myRole);
user.roles.remove(reerole);
  
  
   message.author.send(`${user} have been verified in ${message.guild.name}`)

  if (log === null) {
    return;
  }
  let embed = new Discord.MessageEmbed()
      .setTitle(`verified member!`)
      .setDescription(`${user} was gain access in ${message.guild.name}.
id: ${message.author.id} 
in ${chan}`);
  
   logch.send(embed)
}
                                                  collector.stop();
    
    }else{message.channel.send("Failed Verification!");
          message.channel.send("type v.verify again to start verify.")
		collector.stop();
         }
  })
  }
}