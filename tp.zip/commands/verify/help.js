const Discord = require("discord.js")
const { MessageEmbed } = require('discord.js')
const { dprefix , prefix} = require(`../../config.json`)

module.exports = {
  name: "v.help",
  aliases: ["v.info"],

  run: (client, message, args) => {


 let embed = new MessageEmbed()
.setTitle(`Help`)
.setDescription(`**Here are the all commands:**
My prefix is ${dprefix}
> \`${dprefix}setverify\`: Set verification channel, autodelete channel.
> \`${dprefix}setrole\`: Gives role when they use ${prefix}captcha command in verification channel.
> \`${dprefix}setrrole\`: Removes role when they use ${prefix}captcha command in verification channel.
> \`${prefix}captcha\`: It gives or remove role it works only in verification channel.
> \`${dprefix}rvrole\`: Reset **Give Role** 
> \`${dprefix}rvchannel\`: Reset **Verification Channel**
> \`${dprefix}rrvrole\`: Reset **Remove Role**`)
.setColor("#87CEEB")
.setTimestamp()
  message.channel.send(embed)

  }
}