const Discord = require("discord.js")
const { MessageEmbed } = require('discord.js')
const db = require("quick.db")

module.exports = {
  name: "v.setverify",
  aliases: ["v.sv"],
  category: ":frame_photo: WELCOME",
  run: async (client, message, args) => {


    if (!message.member.hasPermission("ADMINISTRATION")) {
      return message.channel.send("You do not enough permission to use this command.");
    }
    let channel = message.mentions.channels.first()

    if (!channel) {
      return message.channel.send("You have to specify the channel")
    }
    let embed = new MessageEmbed()
      .setTitle(`Help for verify`)
      .setDescription(`type v.verify to access all channel`)
      
      .setFooter(`tip:if you have none verified,you must call help the owener,mod or adimin.`)
      .setColor("#87CEEB")
      .setTimestamp()
    // This code is made by Supreme#2401
    channel.send(embed)
    setTimeout(() => {
    db.set(`verify_${message.guild.id}`, channel.id)
    message.channel.send(`Verification channel updated as ${channel}`)
  }, 2000)
  }
}