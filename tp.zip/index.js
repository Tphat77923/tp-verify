const { prefix, developerID } = require("./config.json")
const { config } = require("dotenv");
const db = require("quick.db");
const welc = require("image-cord")
const Discord = require('discord.js')
const Captcha = require("@haileybot/captcha-generator");
const express = require('express')
const { Client, MessageEmbed } = require('discord.js');
const client = new Discord.Client({
  disableEveryone: false
});
let cooldown = new Set();
let cdseconds = 100; // cooldown time

// This code is made by Supreme#2401


client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

["command"].forEach(handler => {
  require(`./handlers/${handler}`)(client);
});
process.on('UnhandledRejection', console.error);

client.on("message", async message => {
	if (message.content == "v.modstarts") {
		message.channel.send("PONG");
	}
	});

client.on("message", async message => {

  if (message.author.bot) return;
  if (!message.guild) return;
  if (message.content.startsWith(`<@935913403128643638>`)){
    message.channel.send(`hello!who has tag me? my prefix is v.`)
  };
  if (!message.content.startsWith(prefix)) return;

  if (cooldown.has(message.author.id)) {

    return message.channel.send(`**${message.author.username}** wait \`10\` seconds to use this command!`)
  }
  cooldown.add(message.author.id);
  setTimeout(() => {
    cooldown.delete(message.author.id)
  }, cdseconds + 100)
; 
  
  if (!message.member)
  mesage.member = message.guild.fetchMember(message);


  const args = message.content
    .slice(prefix.length)
    .trim()
    .split(/ +/g);
  const cmd = args.shift().toLowerCase();

  if (cmd.length === 0) return;

  let command = client.commands.get(cmd);

  if (!command) command = client.commands.get(client.aliases.get(cmd));

  if (command) command.run(client, message, args);

});


client.on("message", message => {
  const chx = db.get(`verify_${message.guild.id}`);
  const chan = client.channels.cache.get(chx);
  if (chan == message.channel.id){
    if (message.content !== "v.verify" && !message.author.bot){
      message.delete()
    }else{
    return;
      }
  }
});


// Do not change anything here


client.on("ready", () => {
  client.user.setStatus("dnd"); // You can change it to online, dnd, idle

  console.log(`Successfully logined as ${client.user.tag} `)
	require('http').createServer((req, res) => res.end(`
 |-----------------------------------------|
 |              Informations               |
 |-----------------------------------------|
 |• Alive: 24/7                            |
 |-----------------------------------------|
 |• Author: Tphat77923#8231                |
 |-----------------------------------------|
 |• Server: https://discord.gg/gU7XAxTpX5  |
 |-----------------------------------------|
 |• Github: https://github.com/diwasatreya |
 |-----------------------------------------|
 |• License: Apache License 2.0            |
 |-----------------------------------------|
`)).listen(3000) //Dont remove this 
});

//  For Watching Status
client.on("ready", () => {
  client.user.setActivity(`tag me for prefix`, { type: "WATCHING", })
});
// url: "https://www.twitch.tv/nocopyrightsounds"})});

client.login(process.env.TOKEN);
